#imported libraries:
import tkinter as tk

# create a new tk object named "window"
window = tk.Tk()

# set up the window
## geometry is width x height in pixels of the total amount of space the total amount of created tk objects can take up
window.geometry("700x700")

## create a new frame object named "frame". think of it as a program window. all our interface display will be inside this frame
### NOTE:  frame auto-fills the entire above-mentioned geometry (400 x 400 here).
frame = tk.Frame(window)
frame.pack()

## the code below creates a "left side" and "right side" of the frame and orients them to the left and right of the display
''' NOTE: 
creating 2 additional frames splits the window into 3 for positioning: 
            a left side("leftframe") and a right side ("rightside")
Since both leftframe and rightframe are also created with Frame(window), 
"frame", "leftside", and "rightside" are all "aware" of one another existing inside main; which is "window"
'''
leftframe = tk.Frame(window)
leftframe.pack( side = "left" )

rightframe = tk.Frame(window)
rightframe.pack( side = "right" )

# create title label
label0 = tk.Label (frame, text = "Welcome to the budget calculator!")
label0.pack()

# add data from entries to the end of the array; all are strings
   
def create_window():
    ###################### weekly ######################
    # the code below creates the elements for creating a weekly subscription entry
    weekly_amnt = list()
    weekly_sub_names = list()
    m_weeks = list()
    
    print("++++++++++++++++++++++++++++")
    print(m_weeks)
    print(weekly_amnt)
    print(weekly_sub_names)
    print("++++++++++++++++++++++++++++")
    
    label1 = tk.Label (leftframe, text = "How many weeks are in the month?")
    label1.pack()
    weeks_in_month = tk.Entry(leftframe)
    weeks_in_month.pack()
    button1 = tk.Button(leftframe, text = "Submit weeks", command=lambda:on_button(weeks_in_month, m_weeks))
    button1.pack()
    
    label2 = tk.Label (leftframe, text = "Enter subscription/company name")
    label2.pack()
    weekly_name = tk.Entry(leftframe)
    weekly_name.pack()
    button2 = tk.Button(leftframe, text = "Submit name", command=lambda:on_button(weekly_name, weekly_sub_names))
    button2.pack()
    
    label3 = tk.Label(leftframe, text = "Enter amount")
    label3.pack()
    weekly_take_amt = tk.Entry(leftframe)
    weekly_take_amt.pack()
    button3 = tk.Button(leftframe, text = "Submit amount", command=lambda:on_button(weekly_take_amt, weekly_amnt))
    button3.pack()
    
    b_add_weekly_payment = tk.Button(leftframe, text = "Add weekly payment", command=lambda:write_to_weekly_file(m_weeks, weekly_sub_names, weekly_amnt))
    b_add_weekly_payment.pack()
    
    #################### monthly #########################
    payment_due_date = list()
    monthly_sub_names= list()
    monthly_amnt = list()
    
    label4 = tk.Label(rightframe, text = "Enter subscription/company name")
    label4.pack()
    month_sub_name = tk.Entry(rightframe)
    month_sub_name.pack()
    button4 = tk.Button(rightframe, text = "Submit name", command=lambda:on_button(month_sub_name, monthly_sub_names))
    button4.pack()
    
    label5 = tk.Label(rightframe, text = "Enter amount")
    label5.pack()
    month_sub_amt = tk.Entry(rightframe)
    month_sub_amt.pack()
    button5 = tk.Button(rightframe, text = "Submit amount", command=lambda:on_button(month_sub_amt, monthly_amnt))
    button5.pack()
    
    label6 = tk.Label(rightframe, text = "Enter date")
    label6.pack()
    sub_payment_date = tk.Entry(rightframe)
    sub_payment_date.pack()
    button6 = tk.Button(rightframe, text = "Submit date", command=lambda:on_button(sub_payment_date, payment_due_date))
    button6.pack()
    
    b_add_monthly_payments = tk.Button(rightframe, text = "Add monthly payment", command=lambda:write_to_monthly_file(payment_due_date, monthly_sub_names, monthly_amnt))
    b_add_monthly_payments.pack()
    
    #################### paycheck ###################
    paycheck_hours = list()
    paycheck_pay_rate = list()
    
    label7 = tk.Label(frame, text = "Enter hours worked for one week")
    label7.pack()
    paycheck_add_hours = tk.Entry(frame)
    paycheck_add_hours.pack()
    button7 = tk.Button(frame, text = "Submit hours", command=lambda:on_button(paycheck_add_hours, paycheck_hours))
    button7.pack()
    
    label8 = tk.Label(frame, text = "Enter hourly pay rate")
    label8.pack()
    paycheck_hourly_pay = tk.Entry(frame)
    paycheck_hourly_pay.pack()
    button9 = tk.Button(frame, text = "Submit pay rate", command=lambda:on_button(paycheck_hourly_pay, paycheck_pay_rate))
    button9.pack()
    
    button10 = tk.Button(frame, text = "Add paycheck", command=lambda:get_paycheck(paycheck_hours, paycheck_pay_rate))
    button10.pack()
    
    #################### buttons ####################
    
    b_calc_budget = tk.Button(frame, text = "Calculate Budget", command=lambda:calc_total())
    b_calc_budget.pack()

    b_start_over = tk.Button(frame, text = "Create a brand new budget", command=lambda:new_budget()) 
    b_start_over.pack()
    
def on_button(entry, array):
    array.append(str(entry.get()))
    '''print("PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP")
    print(array)
    print("PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP") '''

def check_for_empty_list(check_list):
    for item in check_list:
        if item == '':
            check_list.remove(item)
    return check_list
      
########### START WRITE TO WEEKLY FILE (WEEKLY.TXT) ##########
''' Getting around global vars with writing to files! '''
def write_to_weekly_file(date, names, fees):
    f_copy = open("weekly.txt", "r")
    
    #1. find number of entries
    data_dump = f_copy.read()
    
    # the file no longer needs to read, so close it
    f_copy.close()
    
    # count the number of new-line "characters" in the file
    entry_count = data_dump.count("\n")
    if entry_count == 0:
        entry_count = 1
    
    # open the file and allow it to append
    f_apply = open("weekly.txt", "a")
    
    # first, make sure that there is an equal number of name and fee entries
    if len(names) == len(fees):
    
        #find the index of the most recent entry
        needed_index = len(names)-1
        
        ''' print('777777777777777777777777777777777777')
        print(needed_index)
        print(names)
        print(fees)
        print('777777777777777777777777777777777777') '''
        # string typecasting as precaution
        new_name = names[needed_index]
        new_fee = fees[needed_index]
        new_weeks = date[needed_index]
        
        # add the new entry to the file in the following format:
            
        line_to_write = 'Week expense # {0} is name {1}, fees {2}, and weeks {3}'.format(entry_count, new_name, new_fee, new_weeks)
        '''print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
        print(line_to_write)
        print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$') '''
        if entry_count == 1:
            f_apply.close()
            f_new = open ("weekly.txt", "w")
            f_new.write (line_to_write)
            f_new.close()
        else:
            f_apply.write(line_to_write)
            f_apply.close()
    
        '''we are now going to create a label to display a message to the user
        to tell them that clicking the "Add weekly payment" button actually did 
        something! '''
        #if the file does not contain what we are looking for, we must report that as an error
    else:
        index_error = tk.Label (frame, text = "A critical error has occured.  Please click the 'New Budget' button to restart.")
        index_error.pack()
        return
    
    added_label = tk.Label (frame, text = "Weekly payment entry has been logged.")
    added_label.pack()      
    return
###########################################################################################
##############################################################

''' Getting around global vars with writing to files! '''

def write_to_monthly_file(date, names, fees):
    # open the file as read. 
    f_copy = open("monthly.txt", "r")
    
    #1. find number of entries
    data_dump = f_copy.read()
    
    # the file no longer needs to read, so close it
    f_copy.close()
    
    # count the number of new-line "characters" in the file
    entry_count = data_dump.count("\n")
    if entry_count == 0:
        entry_count = 1
    
    # open the file and allow it to append
    f_apply = open("monthly.txt", "a")
    
    # first, make sure that there is an equal number of name and fee entries
    if len(names) == len(fees):
    
        #find the index of the most recent entry
        needed_index = len(names)-1
        
        print('777777777777777777777777777777777777')
        print(needed_index)
        print(names)
        print(fees)
        print('777777777777777777777777777777777777')
        # string typecasting as precaution
        # NOTE: these 2 vars take the same index because their lengths are equal
        new_name = names[needed_index]
        new_fee = fees[needed_index]
        new_date = date[needed_index]
        
        # add the new entry to the file in the following format:
        line_to_write = 'Monthly expense # {0} is name {1}, fees {2}, date {3}'.format(entry_count, new_name, new_fee, new_date)
        print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
        print(line_to_write)
        print('$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$')
        if entry_count == 1:
            f_apply.close()
            f_new = open ("weekly.txt", "w")
            f_new.write (line_to_write)
            f_new.close()
        else:
            f_apply.write(line_to_write)
            f_apply.close()
        
        # open internal data file. 
        ## note: This is a debug file; its data is never utilized in the program
                
        '''we are now going to create a label to display a message to the user
        to tell them that clicking the "Add weekly payment" button actually did 
        something! '''
        #if the file does not contain what we are looking for, we must report that as an error
    else:
        index_error = tk.Label (frame, text = "A critical error has occured.  Please click the 'New Budget' button to restart.")
        index_error.pack()
        return
    
    added_label = tk.Label (frame, text = "Weekly payment entry has been logged.")
    added_label.pack()      
    return
###########################################################################################

##########################################ADD PAYCHECK####################################
def get_paycheck(hours, payrate):
    # open file as read-only
    f_apply = open("paycheck.txt", "r")
    
    #1. find number of entries
    data_dump = f_apply.read()
    entry_count = data_dump.count("\n")
                          
    # *** and divide by 2 because every paycheck has two appends! ***
    entry_count = entry_count / 2
    
    if entry_count <= 0:
        entry_count = 1
    
    f_apply.close()
    
    # append entry
    f_write = open("paycheck.txt", "a")
    
    needed_index = len (hours) - 1
    
    new_hours = hours[needed_index]
    new_rate = payrate[needed_index]
    
    line_to_write = 'paycheck # {0} is hours  {1} and payrate {2},'.format(entry_count, new_hours, new_rate)
    if entry_count == 1:
        f_write.close()
        f_new = open ("weekly.txt", "w")
        f_new.write (line_to_write)
        f_new.close()
    else:
        f_write.write(line_to_write)
        
    f_write.write(line_to_write)
    
    ####################### calculate paycheck #############################
    
    #1. net pay
    net_pay = int(hours[needed_index]) * int(payrate[needed_index])
    
    # 2. taxes
    tax = net_pay * 0.800
    
    # 3. check
    total = net_pay - tax


    net_pay_and_remaining_check = 'Net pay for check # {0} is ${1}"and remaining check is: ${2} \n'.format(entry_count, net_pay, total)
    f_write.write(net_pay_and_remaining_check)
                          
    f_write.close()
    #########################################################################
    
    success = tk.Label (frame, text = "Paycheck has been successfully logged.")
    success.pack()
    
    return
###########################################################################################
########################## calculate budget ########################
def calc_total():
    expenses = 0
                          
    # 1. read paychecks
    r_checks = open("paycheck.txt", "r")
    check_identifier_key = "Net pay for check #"
    
    # count number of paychecks
    check_dump = r_checks.read()
                          
    num_checks = check_dump.count(check_identifier_key)
    
    
    r_checks.close()
                          
    # catch if no paychecks entered
    if num_checks <= 0:
        check_error0 = tk.Label(frame, text = "The program cannot find any paychecks.  Please create one and try again.")
        check_error0.pack()
        return
    
    money_to_spend = 0.0
    running_total = 0.0
    
    money = open("paycheck.txt", "r")
    money_identifier_key = "and remaining check is:$"
    
    money_read = money.read().splitlines()
    
    # total money
    c = 0
    for x in money_read:
        if money_read[c].startswith(money_identifier_key) == True:
            snip = str(money_read[c])
            pos = snip.index(money_identifier_key) + 2
            
            val = float(snip[pos:].strip())
            money_to_spend += val
        c += 1
        
    # open monthly
    entry_id_key = "Monthly expense #"
    start_pos1 = "name"
    start_pos2 = "fees"
    start_pos3 = "date"
                          
    r_month = open("monthly.txt", "r")
                          
    m_dump = r_month.read()
    num_entries = m_dump.count(entry_id_key)  

    r_month.close()                
    
    # catch if no monthly expenses entered
    if num_entries <= 0:
        check_error1 = tk.Label(frame, text = "The program cannot find any monthly expenses.  Please create one and try again.")
        check_error1.pack()    
        return             
        
    m_entry_array = m_dump.splitlines()
    
    monthly_names= list()
    monthly_fees = list()
    monthly_dates = list()
    
    f = 0
    for y in m_entry_array:
        if m_entry_array[f].startswith(entry_id_key) == True:
            snip1 = str(m_entry_array[f])
            pos = snip1.index(start_pos1) + 4
            end = snip1.index(",")
            entry = str(snip1[pos:end])
            
            monthly_dates.append(entry)
                          
            # clear
            entry = ""
            pos = 0
            end = 0
            
            snip2 = str(m_entry_array[f])
            pos = snip2.index(start_pos2) + 4
            end = snip2.index(",")
            val = float(snip2[pos:end])
            
            monthly_names.append(val)
            expenses += val
                          
            # clear
            val = 0.0
            pos = 0
                          
            snip3 = str(m_entry_array[f])
            pos = snip3.index(start_pos3) + 4
            entry = str(snip3[pos:].strip())
                          
            monthly_fees.append(float(entry)
            
        f += 1
    
    num_entries = 0
    
    # open weekly
    entry_id_key = "Weekly expense #"
    start_pos1 = "name"
    start_pos2 = "fees"
    start_pos3 = "weeks"
                          
    r_weekly = open("weekly.txt", "r")
                          
    w_dump = r_weekly.read()
    num_entries = w_dump.count(entry_id_key)  

    r_weekly.close()                
    
    # catch if no monthly expenses entered
    if num_entries <= 0:
        check_error2 = tk.Label(frame, text = "The program cannot find any weekly expenses.  Please create one and try again.")
        check_error2.pack()
        return            
        
    w_entry_array = w_dump.splitlines()
    
    weekly_names = list()
    weekly_fees = list()
    num_weeks = 0
    
    c = 0
    for y in w_entry_array:
        if w_entry_array[c].startswith(entry_id_key) == True:
            w_snip1 = str(w_entry_array[c])
            pos = w_snip1.index(start_pos1) + 4
            entry = str(w_snip1[pos:])
            
            weekly_names.append(entry)
                          
            # clear
            val = 0
            pos = 0
            
            w_snip2 = str(w_entry_array[c])
            pos = w_snip2.index(start_pos2) + 4
            val = float(snip2[pos:].strip())
                          
            weekly_fees.append(val)
            
            pos= 0
            
            w_snip3 = str(w_entry_array[c])
            pos = w_snip3.index(start_pos3) + 5
            num_weeks = int (snip3[pos:].strip())
            
            expenses += val * num_weeks
        c = c + 1
   
    #calculate over/under budget
    running_total = money_to_spend - expenses
    
    if running_total >= 0:
        remaining_money = tk.Label (frame, "You have $", running_total, "left over.")
        remaining_money.pack()
    else:
        remaining_money = tk.Label (frame, "You are $", running_total * -1, "over your budget.")
        remaining_money.pack()
     
    # display due date/s for monthly payments
    due_dates = ""
                          
    for z in monthly_dates:
        due_dates += str(monthly_dates(z)) + ","
        
    m_date_label = tk.Label (rightframe, "Your monthly payments are due on: ", due_dates)
    m_date_label.pack()
    
    w_dates = ""
                          
    for a in weekly_names:
       w_dates += str(weekly_names(a)) + ","
                          
    w_date_label = tk.Label (rightframe, "Your weekly payments are for:  ", w_dates)
    w_date_label.append()
    
    return
###############################################################################################
############################ new budget; clear all files #######################
def new_budget():
    w_paycheck = open ("paycheck.txt", "w")
    w_paycheck.write("cleared")
    w_paycheck.close()
    
    w_monthly = open ("monthly.txt", "w")
    w_monthly.write("cleared")
    w_paycheck.close()
                          
    w_weekly = open ("weekly.txt", "w")
    w_weekly.write("cleared")
    w_paycheck.close()
    
    return
##############################################################################                          

# call for window to be created!
create_window()

# MUST BE LAST LINE OF CODE; tells the program to create a window and keep it open until the program is (manually) terminated    
tk.mainloop()